sap.ui.define([
	"com/fsoft/zpmmaintenancecockpit/test/unit/controller/MaintenanceOrders.controller"
], function () {
	"use strict";
});
