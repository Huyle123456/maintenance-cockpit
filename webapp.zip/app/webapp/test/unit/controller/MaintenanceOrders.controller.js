/*global QUnit*/

sap.ui.define([
	"com/fsoft/zpmmaintenancecockpit/controller/MaintenanceOrders.controller"
], function (Controller) {
	"use strict";

	QUnit.module("MaintenanceOrders Controller");

	QUnit.test("I should test the MaintenanceOrders controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
